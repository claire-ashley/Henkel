Date and time:     Fri Nov 08 10:23:20 2019
Computer name:     5ZPNTN2
User name:         ashlc00
Windows version:   6.2.9200.2 
Version of vt3:    8.9.2.0-STABLE

Project:           C:\Users\ashlc00\Documents\Henkel\Henkel_RobotLeveling_V0.1\Henkel_RobotLeveling_V0.1.vt3
Project version:   0.0.0.0
Device:            CANVIEW4
Source address:    1

File name        Size (bytes)
.\vt3_app.elf       3561532
.\vt3_app.s19       6632930

End of manifest
