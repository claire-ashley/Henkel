Date and time:     Wed Dec 18 11:02:18 2019
Computer name:     5ZPNTN2
User name:         ashlc00
Windows version:   6.2.9200.2 
Version of vt3:    8.9.2.0-STABLE

Project:           C:\Users\ashlc00\Documents\Henkel\Henkel_RobotLeveling_v1.0.1\Henkel_RobotLeveling_v1.0.1.vt3
Project version:   0.0.0.0
Device:            CANVIEW4
Source address:    1

File name        Size (bytes)
.\vt3_app.elf       3627612
.\vt3_app.s19       6843362

End of manifest
